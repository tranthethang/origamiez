<form method="get" id="search-form" class="search-form clearfix" action="<?php echo esc_url( home_url( '/' ) ); ?>">
    <input autocomplete="off" type="text" value=""
           placeholder="<?php esc_attr_e( 'Enter your keyword...', 'origamiez' ); ?>" name="s" class="search-text"
           maxlength="20">
    <button type="submit" class="search-submit"><span class="fa fa-search"></span></button>
</form>
