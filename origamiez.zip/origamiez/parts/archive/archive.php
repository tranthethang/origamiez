<?php
get_template_part( 'parts/archive/archive', 'two-cols' );