<time class="updated metadata-date"
      datetime="<?php echo get_post_field( 'post_date_gmt', get_the_ID() ); ?>">
	<?php origamiez_get_metadata_prefix(); ?>
	<?php echo get_the_date(); ?>
</time>