<span class="metadata-author vcard author">
	<i class="fa fa-user"></i>
	<span class="fn"><?php the_author(); ?></span>
</span>