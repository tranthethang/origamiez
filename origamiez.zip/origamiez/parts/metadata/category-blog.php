<span class="metadata-categories">
    <i class="fa fa-book"></i>
    <?php the_category( ', ' ); ?>
</span>