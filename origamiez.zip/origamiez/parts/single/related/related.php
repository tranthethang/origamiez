<?php

get_template_part( 'parts/single/related/related', 'flat-list' );